export const translations = {
  bn: {
    // App Branding
    appName: "খাবো কোথায়",
    appEnglishName: "KhaboKothay",
    tagline: "আজ কোথায় খাবো?",
    subTagline: "বাংলাদেশের রেস্তোরাঁ খোঁজ ও ডিল দেখার সেরা অ্যাপ",
    
    // Navigation & Tabs
    navDiscover: "আবিষ্কার করুন",
    navDeals: "বিশেষ অফার",
    navFavorites: "প্রিয় তালিকা",
    navOwnerDashboard: "মালিকের ড্যাশবোর্ড",
    
    // Auth & Roles
    signIn: "সাইন ইন",
    signUp: "সাইন আপ",
    signOut: "সাইন আউট",
    continueWithGoogle: "গুগল দিয়ে সাইন ইন করুন",
    orWithEmail: "অথবা ইমেইল দিয়ে",
    emailPlaceholder: "আপনার ইমেইল",
    passwordPlaceholder: "পাসওয়ার্ড",
    namePlaceholder: "আপনার পুরো নাম",
    phonePlaceholder: "ফোন নম্বর (যেমন: ০১৯৪৮৮৭৯৯৮৪)",
    selectRole: "আমি একজন:",
    roleDiner: "ভোজনরসিক (Diner)",
    roleOwner: "রেস্তোরাঁ মালিক (Restaurant Owner)",
    roleDinerDesc: "রেস্তোরাঁ খুঁজুন, রিভিউ দিন, এবং অফার গ্রহণ করুন",
    roleOwnerDesc: "আপনার রেস্তোরাঁ যুক্ত করুন, অফার পোস্ট করুন ও রিভিউ উত্তর দিন",
    alreadyHaveAccount: "আগে থেকেই অ্যাকাউন্ট আছে? সাইন ইন করুন",
    dontHaveAccount: "অ্যাকাউন্ট নেই? সাইন আপ করুন",
    authError: "অনুরোধটি সম্পন্ন করা যায়নি। অনুগ্রহ করে সঠিক তথ্য প্রদান করুন।",

    // Search & Filters
    searchPlaceholder: "রেস্তোরাঁর নাম দিয়ে খুঁজুন...",
    allAreas: "সকল এলাকা",
    allPrices: "সব বাজেট",
    filterCuisine: "খাবারের ধরন (Cuisine)",
    filterArea: "এলাকা (Location)",
    filterPrice: "মূল্য সীমা",
    hasActiveDeal: "সক্রিয় অফার আছে",
    clearFilters: "ফিল্টার মুছে ফেলুন",
    sortBy: "ক্রমানুসারে:",
    sortRating: "সেরা রেটিং",
    sortReviews: "সর্বাধিক রিভিউ",
    sortNewest: "নতুন যুক্ত",
    resultsFound: "টি রেস্তোরাঁ পাওয়া গেছে",

    // Restaurant Card & Details
    rating: "রেটিং",
    reviewsCount: "টি রিভিউ",
    noReviewsYet: "এখনো কোনো রিভিউ নেই",
    activeDealsBadge: "অফার চালু আছে",
    bookmark: "সংরক্ষণ",
    bookmarked: "সংরক্ষিত",
    callRestaurant: "কল করুন",
    viewDetails: "বিস্তারিত দেখুন",
    locationAddress: "ঠিকানা",
    cuisines: "খাবারের ক্যাটাগরি",
    photoGallery: "ছবি গ্যালারি",
    activeDealsSection: "চলতি বিশেষ অফারসমূহ",
    validUntil: "মেয়াদ শেষ:",
    termsAndConditions: "শর্তাবলী:",
    
    // Reviews
    reviewsHeading: "গ্রাহকদের রিভিউ",
    writeReview: "আপনার রিভিউ লিখুন",
    yourRating: "আপনার রেটিং:",
    yourComment: "আপনার মন্তব্য লিখুন...",
    addPhoto: "ছবি যুক্ত করুন (ঐচ্ছিক)",
    submitReview: "রিভিউ জমা দিন",
    submitting: "জমা হচ্ছে...",
    ownerReplyTitle: "রেস্তোরাঁ মালিকের উত্তর:",
    replyToReview: "উত্তর দিন",
    replyPlaceholder: "গ্রাহকের মন্তব্যের উত্তর লিখুন...",
    sendReply: "উত্তর পাঠান",
    
    // Deals Page
    dealsTitle: "বিশেষ ছাড় ও অফারসমূহ",
    dealsSubtitle: "ঢাকার সেরা রেস্তোরাঁগুলোর চটকদার ডিসকাউন্ট ও বাই-ওয়ান-গেট-ওয়ান অফার",
    noDealsFound: "বর্তমানে কোনো অফার পাওয়া যায়নি।",
    getDealAt: "অফারটি গ্রহণ করতে যান",

    // Diner Favorites
    favoritesTitle: "আপনার পছন্দের রেস্তোরাঁসমূহ",
    noFavoritesYet: "আপনি এখনো কোনো রেস্তোরাঁ বুকমার্ক করেননি। 'সংরক্ষণ' বাটনে চাপ দিয়ে প্রিয় রেস্তোরাঁ জমা রাখুন।",

    // Owner Dashboard
    myRestaurants: "আমার রেস্তোরাঁসমূহ",
    addNewRestaurant: "নতুন রেস্তোরাঁ যোগ করুন",
    editRestaurant: "প্রোফাইল সম্পাদন করুন",
    manageDeals: "অফার পরিচালনা করুন",
    createDeal: "নতুন অফার তৈরি করুন",
    dealTitlePlaceholder: "অফারের নাম (যেমন: ২০% ফ্ল্যাট ডিসকাউন্ট)",
    dealDescPlaceholder: "অফারের বিবরণ (যেমন: প্রতিটি অল ডে মেনুতে ২০% ছাড়)",
    validFromDate: "শুরু তারিখ",
    validUntilDate: "শেষ তারিখ",
    termsPlaceholder: "শর্তাবলী (যেমন: শুধুমাত্র ডাইন-ইনের জন্য প্রযোজ্য)",
    reviewsInbox: "রিভিউ ইনবক্স",
    noRestaurantsOwner: "আপনি এখনো কোনো রেস্তোরাঁ যোগ করেননি। উপরের বাটন চেপে প্রথম রেস্তোরাঁ যোগ করুন!",
    restaurantName: "রেস্তোরাঁর নাম",
    description: "বিবরণ",
    coverPhotoUrl: "কভার ছবির URL / লিংক",
    galleryPhotosUrls: "গ্যালারি ছবির URL (কমা দিয়ে আলাদা করুন)",
    saveRestaurant: "সংরক্ষণ করুন",
    saveDeal: "অফার প্রকাশ করুন",

    // Footer & Contact
    contactTitle: "যোগাযোগ ও সহায়তা",
    supportEmailLabel: "সাপোর্ট ইমেইল:",
    hotlineLabel: "হটলাইন নম্বর:",
    aboutHeading: "খাবো কোথায় সম্পর্কে",
    aboutText: "খাবো কোথায় হলো বাংলাদেশের খাদ্যরসিকদের জন্য তৈরি রেস্তোরাঁ আবিষ্কার ও ডিল খোঁজার আধুনিক প্ল্যাটফর্ম।",
    copyright: "© ২০২৬ খাবো কোথায় (KhaboKothay)। সর্বস্বত্ব সংরক্ষিত।",
    
    // Empty & Loading States
    loadingData: "তথ্য লোড হচ্ছে...",
    noRestaurantsMatch: "আপনার ফিল্টারের সাথে মিলে এমন কোনো রেস্তোরাঁ পাওয়া যায়নি।",
    errorOccurred: "একটি ত্রুটি ঘটেছে। আবার চেষ্টা করুন।",
    mustBeLoggedInDiner: "রিভিউ দিতে বা বুকমার্ক করতে অনুগ্রহ করে আপনার Diner অ্যাকাউন্টে সাইন ইন করুন।",
    mustBeLoggedInOwner: "রেস্তোরাঁ পরিচালনা করতে অনুগ্রহ করে আপনার Owner অ্যাকাউন্টে সাইন ইন করুন।"
  },
  en: {
    // App Branding
    appName: "KhaboKothay",
    appEnglishName: "KhaboKothay",
    tagline: "Where to eat today?",
    subTagline: "Bangladesh's Premier Restaurant Discovery & Deals Platform",
    
    // Navigation & Tabs
    navDiscover: "Discover",
    navDeals: "Offers & Deals",
    navFavorites: "Favorites",
    navOwnerDashboard: "Owner Portal",
    
    // Auth & Roles
    signIn: "Sign In",
    signUp: "Sign Up",
    signOut: "Sign Out",
    continueWithGoogle: "Continue with Google",
    orWithEmail: "or with Email",
    emailPlaceholder: "Your email address",
    passwordPlaceholder: "Password",
    namePlaceholder: "Your full name",
    phonePlaceholder: "Phone number (e.g. 01948879984)",
    selectRole: "I am a:",
    roleDiner: "Diner",
    roleOwner: "Restaurant Owner",
    roleDinerDesc: "Discover restaurants, write reviews, and unlock deals",
    roleOwnerDesc: "Manage your restaurant listings, post deals & reply to reviews",
    alreadyHaveAccount: "Already have an account? Sign In",
    dontHaveAccount: "Don't have an account? Sign Up",
    authError: "Could not complete authentication. Please verify your details.",

    // Search & Filters
    searchPlaceholder: "Search restaurant by name...",
    allAreas: "All Locations",
    allPrices: "All Price Ranges",
    filterCuisine: "Cuisine Type",
    filterArea: "Area / Location",
    filterPrice: "Price Range",
    hasActiveDeal: "Has Active Deals",
    clearFilters: "Clear Filters",
    sortBy: "Sort by:",
    sortRating: "Highest Rating",
    sortReviews: "Most Reviews",
    sortNewest: "Newly Added",
    resultsFound: "restaurants found",

    // Restaurant Card & Details
    rating: "Rating",
    reviewsCount: "reviews",
    noReviewsYet: "No reviews yet",
    activeDealsBadge: "Active Offer",
    bookmark: "Bookmark",
    bookmarked: "Bookmarked",
    callRestaurant: "Call Restaurant",
    viewDetails: "View Details",
    locationAddress: "Address",
    cuisines: "Cuisines",
    photoGallery: "Photo Gallery",
    activeDealsSection: "Active Special Deals",
    validUntil: "Valid Until:",
    termsAndConditions: "Terms & Conditions:",
    
    // Reviews
    reviewsHeading: "Customer Reviews",
    writeReview: "Write a Review",
    yourRating: "Your Rating:",
    yourComment: "Write your review comment...",
    addPhoto: "Add Photo (Optional)",
    submitReview: "Submit Review",
    submitting: "Submitting...",
    ownerReplyTitle: "Restaurant Owner Reply:",
    replyToReview: "Reply",
    replyPlaceholder: "Write a reply to this customer review...",
    sendReply: "Send Reply",
    
    // Deals Page
    dealsTitle: "Exclusive Dining Deals",
    dealsSubtitle: "Discover current discounts, BOGO offers, and promos across top restaurants in Dhaka",
    noDealsFound: "No active deals found right now.",
    getDealAt: "Redeem deal at",

    // Diner Favorites
    favoritesTitle: "Your Saved Restaurants",
    noFavoritesYet: "You haven't bookmarked any restaurants yet. Tap the bookmark icon on any restaurant card to save your favorites.",

    // Owner Dashboard
    myRestaurants: "My Restaurants",
    addNewRestaurant: "Add New Restaurant",
    editRestaurant: "Edit Profile",
    manageDeals: "Manage Deals",
    createDeal: "Create New Deal",
    dealTitlePlaceholder: "Deal Title (e.g., 20% Flat Discount)",
    dealDescPlaceholder: "Deal Description (e.g., 20% off all main courses)",
    validFromDate: "Valid From",
    validUntilDate: "Valid Until",
    termsPlaceholder: "Terms & conditions (e.g. Applicable for dine-in only)",
    reviewsInbox: "Reviews Inbox",
    noRestaurantsOwner: "You haven't added any restaurants yet. Click 'Add New Restaurant' to publish your listing!",
    restaurantName: "Restaurant Name",
    description: "Description",
    coverPhotoUrl: "Cover Photo Image URL",
    galleryPhotosUrls: "Gallery Image URLs (comma separated)",
    saveRestaurant: "Save Restaurant",
    saveDeal: "Publish Deal",

    // Footer & Contact
    contactTitle: "Contact & Support",
    supportEmailLabel: "Support Email:",
    hotlineLabel: "Hotline:",
    aboutHeading: "About KhaboKothay",
    aboutText: "KhaboKothay is Bangladesh's premier restaurant discovery and deals platform designed for food enthusiasts exploring dining options, menus, and discounts.",
    copyright: "© 2026 KhaboKothay. All rights reserved.",

    // Empty & Loading States
    loadingData: "Loading details...",
    noRestaurantsMatch: "No restaurants matched your filter criteria.",
    errorOccurred: "An error occurred. Please try again.",
    mustBeLoggedInDiner: "Please sign in as a Diner to post reviews or save favorites.",
    mustBeLoggedInOwner: "Please sign in as a Restaurant Owner to manage listings."
  }
};
