import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  signOut as firebaseSignOut,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { UserProfile, UserRole, Language } from '../types';

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signInEmail: (email: string, pass: string) => Promise<void>;
  signUpEmail: (email: string, pass: string, name: string, role: UserRole, phone?: string) => Promise<void>;
  signInGoogle: (roleForNewUser?: UserRole) => Promise<void>;
  signOut: () => Promise<void>;
  toggleFavorite: (restaurantId: string) => Promise<void>;
  isFavorite: (restaurantId: string) => boolean;
  updateLanguagePref: (lang: Language) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Sync user profile from Firestore
  const fetchUserProfile = async (uid: string, emailStr?: string, nameStr?: string) => {
    try {
      const userDocRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userDocRef);
      
      if (userSnap.exists()) {
        const data = userSnap.data() as UserProfile;
        setUserProfile({ ...data, uid });
      } else {
        // Create default profile if not present
        const newProfile: UserProfile = {
          uid,
          role: 'diner',
          name: nameStr || emailStr?.split('@')[0] || 'Foodie',
          email: emailStr || '',
          favorites: [],
          createdAt: new Date().toISOString()
        };
        await setDoc(userDocRef, newProfile);
        setUserProfile(newProfile);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `users/${uid}`);
      // Fallback in-memory profile if Firestore user doc fails
      setUserProfile({
        uid,
        role: 'diner',
        name: nameStr || 'Foodie',
        email: emailStr || '',
        favorites: []
      });
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        await fetchUserProfile(user.uid, user.email || '', user.displayName || '');
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInEmail = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      await fetchUserProfile(res.user.uid, res.user.email || '');
    } catch (err: any) {
      setLoading(false);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signUpEmail = async (email: string, pass: string, name: string, role: UserRole, phone?: string) => {
    setLoading(true);
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      const newProfile: UserProfile = {
        uid: res.user.uid,
        role,
        name,
        email,
        phone: phone || '',
        favorites: [],
        createdAt: new Date().toISOString()
      };
      await setDoc(doc(db, 'users', res.user.uid), newProfile);
      setUserProfile(newProfile);
    } catch (err: any) {
      setLoading(false);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signInGoogle = async (roleForNewUser: UserRole = 'diner') => {
    setLoading(true);
    try {
      const res = await signInWithPopup(auth, googleProvider);
      const uid = res.user.uid;
      const userDocRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userDocRef);

      if (userSnap.exists()) {
        const data = userSnap.data() as UserProfile;
        setUserProfile({ ...data, uid });
      } else {
        const newProfile: UserProfile = {
          uid,
          role: roleForNewUser,
          name: res.user.displayName || 'Foodie',
          email: res.user.email || '',
          favorites: [],
          createdAt: new Date().toISOString()
        };
        await setDoc(userDocRef, newProfile);
        setUserProfile(newProfile);
      }
    } catch (err: any) {
      setLoading(false);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
    setUserProfile(null);
  };

  const isFavorite = (restaurantId: string): boolean => {
    if (!userProfile || !userProfile.favorites) return false;
    return userProfile.favorites.includes(restaurantId);
  };

  const toggleFavorite = async (restaurantId: string) => {
    if (!userProfile || !userProfile.uid) {
      throw new Error("MUST_LOGIN_DINER");
    }

    const currentFavs = userProfile.favorites || [];
    const exists = currentFavs.includes(restaurantId);
    const updatedFavs = exists 
      ? currentFavs.filter(id => id !== restaurantId) 
      : [...currentFavs, restaurantId];

    // Optimistic UI update
    setUserProfile({
      ...userProfile,
      favorites: updatedFavs
    });

    try {
      const userRef = doc(db, 'users', userProfile.uid);
      if (exists) {
        await updateDoc(userRef, { favorites: arrayRemove(restaurantId) });
      } else {
        await updateDoc(userRef, { favorites: arrayUnion(restaurantId) });
      }
    } catch (err) {
      console.warn("Firestore update favorites failed, saved in session:", err);
    }
  };

  const updateLanguagePref = async (lang: Language) => {
    if (userProfile && userProfile.uid) {
      setUserProfile({ ...userProfile, languagePreference: lang });
      try {
        await updateDoc(doc(db, 'users', userProfile.uid), { languagePreference: lang });
      } catch (e) {
        // Ignore silent error
      }
    }
  };

  return (
    <AuthContext.Provider value={{
      firebaseUser,
      userProfile,
      loading,
      signInEmail,
      signUpEmail,
      signInGoogle,
      signOut,
      toggleFavorite,
      isFavorite,
      updateLanguagePref
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
