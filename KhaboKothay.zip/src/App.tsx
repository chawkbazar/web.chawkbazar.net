import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, getDocs } from 'firebase/firestore';
import { db, seedInitialDataIfNeeded } from './lib/firebase';
import { Restaurant, Deal, FilterState } from './types';
import { LanguageProvider } from './context/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { FilterBar } from './components/FilterBar';
import { RestaurantCard } from './components/RestaurantCard';
import { RestaurantDetailModal } from './components/RestaurantDetailModal';
import { AuthModal } from './components/AuthModal';
import { DealsView } from './components/DealsView';
import { FavoritesView } from './components/FavoritesView';
import { OwnerDashboard } from './components/OwnerDashboard';
import { Sparkles, Utensils, AlertTriangle } from 'lucide-react';

function MainContent() {
  const { t } = useLanguage();
  const { userProfile } = useAuth();

  const [activeTab, setActiveTab] = useState<'discover' | 'deals' | 'favorites' | 'owner'>('discover');
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Selected Restaurant Modal
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);

  // Auth Modal State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Filters
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    selectedCuisines: [],
    selectedArea: 'all',
    selectedPriceRange: 'all',
    hasActiveDealOnly: false,
    sortBy: 'rating'
  });

  useEffect(() => {
    // Seed initial restaurants if database is empty
    seedInitialDataIfNeeded();

    // Listen to live restaurants updates
    const unsubscribeRes = onSnapshot(collection(db, 'restaurants'), async (snapshot) => {
      const resList: Restaurant[] = [];
      const allDeals: Deal[] = [];

      for (const dDoc of snapshot.docs) {
        const resData = { id: dDoc.id, ...dDoc.data() } as Restaurant;

        // Fetch subcollection deals
        try {
          const dealsSnap = await getDocs(collection(db, `restaurants/${dDoc.id}/deals`));
          const todayStr = new Date().toISOString().split('T')[0];
          let hasActive = false;

          dealsSnap.forEach(dealDoc => {
            const dealData = dealDoc.data() as Deal;
            if (!dealData.validUntil || dealData.validUntil >= todayStr) {
              hasActive = true;
              allDeals.push({
                id: dealDoc.id,
                restaurantId: dDoc.id,
                restaurantName: resData.name,
                restaurantCover: resData.coverPhotoUrl,
                restaurantArea: resData.area,
                ...dealData
              });
            }
          });

          resData.hasActiveDeal = hasActive;
        } catch (e) {
          // ignore subcollection read error if rules restrict
        }

        resList.push(resData);
      }

      setRestaurants(resList);
      setDeals(allDeals);
      setLoading(false);
    }, (err) => {
      console.warn("Firestore subscription error:", err);
      setLoading(false);
    });

    return () => unsubscribeRes();
  }, []);

  // Filter restaurants
  const filteredRestaurants = restaurants.filter(res => {
    // Search query
    if (filters.searchQuery.trim()) {
      const q = filters.searchQuery.toLowerCase();
      const nameMatch = res.name?.toLowerCase().includes(q);
      const areaMatch = res.area?.toLowerCase().includes(q);
      const descMatch = res.description?.toLowerCase().includes(q);
      if (!nameMatch && !areaMatch && !descMatch) return false;
    }

    // Area
    if (filters.selectedArea !== 'all' && res.area !== filters.selectedArea) {
      return false;
    }

    // Price
    if (filters.selectedPriceRange !== 'all' && res.priceRange !== filters.selectedPriceRange) {
      return false;
    }

    // Active Deal Filter
    if (filters.hasActiveDealOnly && !res.hasActiveDeal) {
      return false;
    }

    // Cuisine Tags (match if restaurant has any of selected cuisines)
    if (filters.selectedCuisines.length > 0) {
      const hasCuisine = filters.selectedCuisines.some(c => res.cuisineTags?.includes(c));
      if (!hasCuisine) return false;
    }

    return true;
  }).sort((a, b) => {
    if (filters.sortBy === 'rating') {
      return (b.avgRating || 0) - (a.avgRating || 0);
    }
    if (filters.sortBy === 'reviews') {
      return (b.reviewCount || 0) - (a.reviewCount || 0);
    }
    if (filters.sortBy === 'newest') {
      return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    }
    return 0;
  });

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-stone-800">
      
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Body per Active Tab */}
      <main className="flex-1">
        {activeTab === 'discover' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
            
            {/* Hero Header Card */}
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-amber-900 via-amber-800 to-red-950 text-white p-6 sm:p-10 shadow-xl">
              <div className="relative z-10 max-w-2xl space-y-2">
                <div className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-300/30 px-3 py-1 rounded-full text-amber-300 text-xs font-semibold backdrop-blur-md">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t('subTagline')}</span>
                </div>
                <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                  {t('tagline')}
                </h1>
                <p className="text-xs sm:text-sm text-stone-200 leading-relaxed pt-1">
                  Browse authentic food menus, check ratings, read reviews, and grab deals across Dhanmondi, Gulshan, Banani, Uttara, Mirpur, and Dhaka.
                </p>
              </div>

              {/* Decorative Background Accent */}
              <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none transform translate-x-10 translate-y-10">
                <Utensils className="w-80 h-80 text-white" />
              </div>
            </div>

            {/* Filter Bar */}
            <FilterBar
              filters={filters}
              setFilters={setFilters}
              totalResults={filteredRestaurants.length}
            />

            {/* Restaurant Cards Grid */}
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <div key={i} className="bg-white rounded-2xl h-72 animate-pulse border border-stone-200" />
                ))}
              </div>
            ) : filteredRestaurants.length === 0 ? (
              <div className="bg-white rounded-3xl p-10 border border-stone-200 text-center space-y-3">
                <AlertTriangle className="w-10 h-10 text-amber-600 mx-auto" />
                <p className="text-stone-700 font-semibold text-sm">
                  {t('noRestaurantsMatch')}
                </p>
                <button
                  onClick={() => setFilters({
                    searchQuery: '',
                    selectedCuisines: [],
                    selectedArea: 'all',
                    selectedPriceRange: 'all',
                    hasActiveDealOnly: false,
                    sortBy: 'rating'
                  })}
                  className="px-4 py-2 bg-amber-700 text-white font-bold text-xs rounded-xl hover:bg-amber-800 transition-colors"
                >
                  {t('clearFilters')}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredRestaurants.map(restaurant => (
                  <RestaurantCard
                    key={restaurant.id}
                    restaurant={restaurant}
                    onSelect={(res) => setSelectedRestaurant(res)}
                    onRequireAuth={() => setIsAuthModalOpen(true)}
                  />
                ))}
              </div>
            )}

          </div>
        )}

        {activeTab === 'deals' && (
          <DealsView
            deals={deals}
            restaurants={restaurants}
            onSelectRestaurant={(res) => setSelectedRestaurant(res)}
          />
        )}

        {activeTab === 'favorites' && (
          <FavoritesView
            restaurants={restaurants}
            onSelectRestaurant={(res) => setSelectedRestaurant(res)}
            onRequireAuth={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === 'owner' && (
          <OwnerDashboard />
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <RestaurantDetailModal
        restaurant={selectedRestaurant}
        onClose={() => setSelectedRestaurant(null)}
        onRequireAuth={() => setIsAuthModalOpen(true)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MainContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
