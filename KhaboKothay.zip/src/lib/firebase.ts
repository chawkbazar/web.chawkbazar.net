import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut as firebaseSignOut 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  collection, 
  getDocs, 
  addDoc, 
  setDoc,
  serverTimestamp
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAnalytics, isSupported } from 'firebase/analytics';

export const firebaseConfig = {
  apiKey: "AIzaSyCsG6Dn8gOmNzJsm7Btq48ny2PllnI2sWg",
  authDomain: "khabokothay.firebaseapp.com",
  projectId: "khabokothay",
  storageBucket: "khabokothay.firebasestorage.app",
  messagingSenderId: "15291162780",
  appId: "1:15291162780:web:3338246f87d5a2fbee0d59",
  measurementId: "G-8RP09G2Y85"
};

// Initialize Firebase App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

// Analytics setup
export let analytics: ReturnType<typeof getAnalytics> | null = null;
if (typeof window !== 'undefined') {
  isSupported().then(supported => {
    if (supported) {
      analytics = getAnalytics(app);
    }
  }).catch(() => {});
}

// Skill mandated Firestore error handler
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error Details: ', JSON.stringify(errInfo));
  return errInfo;
}

// Test connection on boot
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('offline')) {
      console.warn("Firestore appears offline or initializing.");
    }
  }
}
testConnection();

// Initial Seed Data for Bangladesh Restaurants
const SAMPLE_RESTAURANTS = [
  {
    name: "Kacchi Bhai - Dhanmondi",
    description: "Famous for traditional Basmati Kacchi Biryani, Borhani, and Zafrani Firni in Dhaka.",
    cuisineTags: ["Kacchi & Biryani", "Bangladeshi"],
    area: "Dhanmondi",
    address: "House 54, Road 11/A, Dhanmondi, Dhaka",
    priceRange: "৳৳",
    coverPhotoUrl: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1200&q=80",
    galleryPhotoUrls: [
      "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=800&q=80"
    ],
    phone: "01711223344",
    avgRating: 4.8,
    reviewCount: 24,
    ownerId: "sample_owner_1"
  },
  {
    name: "Sultan's Dine - Gulshan",
    description: "Royal Kacchi Feast served with Mutton Kacchi, Roast, Jali Kebab, Chutney & Chutney.",
    cuisineTags: ["Kacchi & Biryani", "Bangladeshi", "Kebab & Grill"],
    area: "Gulshan",
    address: "Green Grandeur, Plot 58, Block E, Road 134, Gulshan 1, Dhaka",
    priceRange: "৳৳৳",
    coverPhotoUrl: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=1200&q=80",
    galleryPhotoUrls: [
      "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80"
    ],
    phone: "01811998877",
    avgRating: 4.9,
    reviewCount: 42,
    ownerId: "sample_owner_1"
  },
  {
    name: "Star Kabab & Restaurant - Baily Road",
    description: "Iconic Dhaka eatery famous for Mutton Faluda, Boti Kabab, Sheek Kebab, and Special Paratha.",
    cuisineTags: ["Kebab & Grill", "Bangladeshi", "Fast Food"],
    area: "Baily Road",
    address: "14 Baily Road, Ramna, Dhaka",
    priceRange: "৳",
    coverPhotoUrl: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=1200&q=80",
    galleryPhotoUrls: [
      "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=800&q=80"
    ],
    phone: "01911445566",
    avgRating: 4.6,
    reviewCount: 19,
    ownerId: "sample_owner_2"
  },
  {
    name: "Takeout Gourmet Burgers - Banani",
    description: "Pioneer of gourmet handcrafted juicy beef & chicken burgers in Bangladesh.",
    cuisineTags: ["Fast Food", "Continental"],
    area: "Banani",
    address: "House 32, Road 11, Block F, Banani, Dhaka",
    priceRange: "৳৳",
    coverPhotoUrl: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=80",
    galleryPhotoUrls: [
      "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80"
    ],
    phone: "01611887766",
    avgRating: 4.7,
    reviewCount: 31,
    ownerId: "sample_owner_2"
  },
  {
    name: "Chillox - Uttara",
    description: "Ultra-popular burger joint famous for juicy double cheese burgers, loaded fries & shakes.",
    cuisineTags: ["Fast Food", "Cafe & Snacks"],
    area: "Uttara",
    address: "Sector 3, Jasimuddin Avenue, Uttara, Dhaka",
    priceRange: "৳",
    coverPhotoUrl: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1200&q=80",
    galleryPhotoUrls: [
      "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80"
    ],
    phone: "01511223344",
    avgRating: 4.5,
    reviewCount: 15,
    ownerId: "sample_owner_3"
  },
  {
    name: "Chef's Table - Gulshan",
    description: "Dhaka's premium food court featuring multi-cuisine gourmet options from Asian to Italian.",
    cuisineTags: ["Continental", "Chinese", "Thai", "Dessert"],
    area: "Gulshan",
    address: "Unimart, Gulshan 2, Dhaka",
    priceRange: "৳৳৳",
    coverPhotoUrl: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
    galleryPhotoUrls: [
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
    ],
    phone: "01948879984",
    avgRating: 4.8,
    reviewCount: 50,
    ownerId: "sample_owner_3"
  }
];

const SAMPLE_DEALS = [
  {
    title: "20% Flat Discount on Kacchi Platter",
    description: "Get 20% off total bill on Basmati Kacchi Feast for 2 persons.",
    validFrom: "2026-08-01",
    validUntil: "2026-09-30",
    terms: "Valid for dine-in only at Dhanmondi branch."
  },
  {
    title: "Buy 1 Get 1 Free Gourmet Burger",
    description: "Buy any Double Beef Cheese Burger and get 1 Classic Burger free!",
    validFrom: "2026-08-05",
    validUntil: "2026-08-31",
    terms: "Applicable on weekdays between 3 PM and 7 PM."
  }
];

export async function seedInitialDataIfNeeded() {
  try {
    const resCol = collection(db, 'restaurants');
    const snapshot = await getDocs(resCol);
    if (snapshot.empty) {
      console.log("Seeding initial Bangladesh restaurant listings to Firestore...");
      for (const item of SAMPLE_RESTAURANTS) {
        const docRef = await addDoc(resCol, {
          ...item,
          createdAt: new Date().toISOString()
        });

        // Add sample deal for the first two
        if (item.name.includes("Kacchi") || item.name.includes("Takeout")) {
          const dealData = item.name.includes("Kacchi") ? SAMPLE_DEALS[0] : SAMPLE_DEALS[1];
          const dealsCol = collection(db, `restaurants/${docRef.id}/deals`);
          await addDoc(dealsCol, {
            ...dealData,
            createdAt: new Date().toISOString()
          });
        }

        // Add sample review
        const reviewsCol = collection(db, `restaurants/${docRef.id}/reviews`);
        await addDoc(reviewsCol, {
          userId: "user_sample_diner",
          userName: "Anik Rahman",
          rating: 5,
          comment: "খাবারের মান খুবই চমৎকার ছিল! সার্ভিসও অনেক দ্রুত। বিশেষ করে খাসির কাচ্চি একদম মুখে মিলিয়ে যায়।",
          ownerReply: "ধন্যবাদ অনিক ভাই! আবার আসবেন!",
          createdAt: new Date(Date.now() - 86400000 * 2).toISOString()
        });
      }
    }
  } catch (err) {
    console.warn("Auto-seeding check complete or skipped based on permissions.");
  }
}
