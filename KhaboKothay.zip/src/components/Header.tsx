import React, { useState } from 'react';
import { UtensilsCrossed, Globe, User, LogOut, Bookmark, Tag, Sparkles, Store, ChevronDown } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  activeTab: 'discover' | 'deals' | 'favorites' | 'owner';
  setActiveTab: (tab: 'discover' | 'deals' | 'favorites' | 'owner') => void;
  onOpenAuthModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenAuthModal }) => {
  const { language, setLanguage, t } = useLanguage();
  const { userProfile, signOut } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const toggleLanguage = () => {
    setLanguage(language === 'bn' ? 'en' : 'bn');
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-amber-900/10 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Tagline */}
          <div 
            onClick={() => setActiveTab('discover')}
            className="flex items-center gap-2.5 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-600 to-red-700 flex items-center justify-center text-amber-50 shadow-md group-hover:scale-105 transition-transform">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xl tracking-tight text-amber-950 font-sans">
                  {language === 'bn' ? 'খাবো কোথায়' : 'KhaboKothay'}
                </span>
                <span className="text-xs px-1.5 py-0.5 rounded-full bg-amber-200/60 text-amber-900 font-medium">
                  BD
                </span>
              </div>
              <p className="text-[11px] text-stone-500 font-medium leading-none hidden xs:block">
                {t('tagline')}
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 bg-stone-200/50 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('discover')}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'discover'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-stone-700 hover:text-amber-900 hover:bg-stone-200'
              }`}
            >
              {t('navDiscover')}
            </button>
            <button
              onClick={() => setActiveTab('deals')}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'deals'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-stone-700 hover:text-amber-900 hover:bg-stone-200'
              }`}
            >
              <Tag className="w-3.5 h-3.5 text-amber-300" />
              {t('navDeals')}
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-all ${
                activeTab === 'favorites'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-stone-700 hover:text-amber-900 hover:bg-stone-200'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              {t('navFavorites')}
            </button>
            {userProfile?.role === 'owner' && (
              <button
                onClick={() => setActiveTab('owner')}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1.5 transition-all ${
                  activeTab === 'owner'
                    ? 'bg-red-700 text-white shadow-xs'
                    : 'text-red-800 hover:bg-red-100/60'
                }`}
              >
                <Store className="w-3.5 h-3.5" />
                {t('navOwnerDashboard')}
              </button>
            )}
          </nav>

          {/* Right Actions: Language Switcher & Profile */}
          <div className="flex items-center gap-2">
            
            {/* Bilingual Switcher Toggle */}
            <button
              onClick={toggleLanguage}
              title={language === 'bn' ? 'Switch to English' : 'বাংলা ভাষায় পরিবর্তন করুন'}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-100/80 hover:bg-amber-200/70 border border-amber-300/50 text-amber-950 font-semibold text-xs transition-colors shadow-2xs"
            >
              <Globe className="w-3.5 h-3.5 text-amber-700" />
              <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>

            {/* Auth / Account Profile Button */}
            {userProfile ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-stone-200 hover:border-amber-400 shadow-2xs text-stone-800 transition-all"
                >
                  <div className="w-7 h-7 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
                    {userProfile.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-xs font-semibold max-w-[100px] truncate hidden sm:inline">
                    {userProfile.name}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
                </button>

                {/* Dropdown Menu */}
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-stone-200 py-2 z-50 text-xs text-stone-700">
                    <div className="px-3 py-2 border-b border-stone-100">
                      <p className="font-bold text-stone-900 truncate">{userProfile.name}</p>
                      <p className="text-stone-500 truncate">{userProfile.email}</p>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-800 uppercase">
                        {userProfile.role === 'owner' ? t('roleOwner') : t('roleDiner')}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        setActiveTab('favorites');
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-amber-50 flex items-center gap-2"
                    >
                      <Bookmark className="w-4 h-4 text-amber-700" />
                      {t('navFavorites')}
                    </button>

                    {userProfile.role === 'owner' && (
                      <button
                        onClick={() => {
                          setActiveTab('owner');
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-amber-50 flex items-center gap-2 text-red-700 font-medium"
                      >
                        <Store className="w-4 h-4" />
                        {t('navOwnerDashboard')}
                      </button>
                    )}

                    <div className="border-t border-stone-100 my-1" />

                    <button
                      onClick={() => {
                        signOut();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-red-50 text-red-600 flex items-center gap-2 font-medium"
                    >
                      <LogOut className="w-4 h-4" />
                      {t('signOut')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuthModal}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs shadow-sm transition-transform active:scale-95"
              >
                <User className="w-3.5 h-3.5" />
                <span>{t('signIn')}</span>
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Mobile Tab Bar */}
      <div className="md:hidden flex border-t border-amber-900/10 bg-white/80 px-2 py-1 justify-around text-xs font-medium text-stone-600">
        <button
          onClick={() => setActiveTab('discover')}
          className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg ${
            activeTab === 'discover' ? 'text-amber-700 font-bold bg-amber-50' : ''
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>{t('navDiscover')}</span>
        </button>

        <button
          onClick={() => setActiveTab('deals')}
          className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg ${
            activeTab === 'deals' ? 'text-amber-700 font-bold bg-amber-50' : ''
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>{t('navDeals')}</span>
        </button>

        <button
          onClick={() => setActiveTab('favorites')}
          className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg ${
            activeTab === 'favorites' ? 'text-amber-700 font-bold bg-amber-50' : ''
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>{t('navFavorites')}</span>
        </button>

        {userProfile?.role === 'owner' && (
          <button
            onClick={() => setActiveTab('owner')}
            className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg ${
              activeTab === 'owner' ? 'text-red-700 font-bold bg-red-50' : ''
            }`}
          >
            <Store className="w-4 h-4" />
            <span>{t('navOwnerDashboard')}</span>
          </button>
        )}
      </div>
    </header>
  );
};
