import React, { useState } from 'react';
import { Star, Upload, Image as ImageIcon, Send, X } from 'lucide-react';
import { collection, addDoc, doc, updateDoc, getDocs } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

interface ReviewFormProps {
  restaurantId: string;
  onReviewSubmitted: () => void;
  onRequireAuth: () => void;
}

export const ReviewForm: React.FC<ReviewFormProps> = ({ 
  restaurantId, 
  onReviewSubmitted,
  onRequireAuth 
}) => {
  const { t } = useLanguage();
  const { userProfile } = useAuth();

  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState<string>('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  if (!userProfile) {
    return (
      <div className="bg-amber-50/80 border border-amber-200/80 rounded-2xl p-4 text-center my-4">
        <p className="text-xs text-amber-900 font-semibold mb-2">
          {t('mustBeLoggedInDiner')}
        </p>
        <button
          onClick={onRequireAuth}
          className="px-4 py-1.5 bg-amber-700 text-white rounded-xl text-xs font-bold hover:bg-amber-800 transition-colors shadow-2xs"
        >
          {t('signIn')}
        </button>
      </div>
    );
  }

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPhotoFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) {
      setError("Please write a comment for your review.");
      return;
    }

    setLoading(true);
    setError('');

    try {
      let uploadedPhotoUrl = '';

      // Upload review photo to Firebase Storage if selected
      if (photoFile && userProfile.uid) {
        try {
          const storageRef = ref(storage, `review-photos/${userProfile.uid}/${Date.now()}_${photoFile.name}`);
          await uploadBytes(storageRef, photoFile);
          uploadedPhotoUrl = await getDownloadURL(storageRef);
        } catch (storageErr) {
          console.warn("Storage upload failed, proceeding without image:", storageErr);
        }
      }

      // Add review to subcollection
      const reviewsRef = collection(db, `restaurants/${restaurantId}/reviews`);
      await addDoc(reviewsRef, {
        restaurantId,
        userId: userProfile.uid,
        userName: userProfile.name || 'Foodie Diner',
        rating,
        comment: comment.trim(),
        photoUrl: uploadedPhotoUrl || '',
        createdAt: new Date().toISOString()
      });

      // Recalculate average rating & review count for restaurant
      try {
        const reviewsSnap = await getDocs(reviewsRef);
        let total = 0;
        let count = 0;
        reviewsSnap.forEach(rDoc => {
          const rData = rDoc.data();
          if (rData.rating) {
            total += rData.rating;
            count += 1;
          }
        });
        const newAvg = count > 0 ? parseFloat((total / count).toFixed(1)) : rating;

        await updateDoc(doc(db, 'restaurants', restaurantId), {
          avgRating: newAvg,
          reviewCount: count
        });
      } catch (calcErr) {
        console.warn("Could not recalculate average rating:", calcErr);
      }

      setComment('');
      setPhotoFile(null);
      setPhotoPreview('');
      setRating(5);
      onReviewSubmitted();
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, `restaurants/${restaurantId}/reviews`);
      setError(err.message || t('errorOccurred'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-stone-50 border border-stone-200 rounded-2xl p-4 my-4 space-y-3">
      <h4 className="font-bold text-sm text-stone-900 flex items-center gap-1.5">
        <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
        <span>{t('writeReview')}</span>
      </h4>

      {error && (
        <p className="text-xs text-red-600 bg-red-50 p-2 rounded-lg font-medium">{error}</p>
      )}

      {/* Star selector */}
      <div>
        <label className="block text-xs font-semibold text-stone-600 mb-1">
          {t('yourRating')}
        </label>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(star)}
              className="p-1 hover:scale-110 transition-transform"
            >
              <Star
                className={`w-6 h-6 ${
                  (hoverRating || rating) >= star
                    ? 'text-amber-500 fill-amber-500'
                    : 'text-stone-300'
                }`}
              />
            </button>
          ))}
          <span className="text-xs font-bold text-stone-700 ml-2">
            {rating} / 5
          </span>
        </div>
      </div>

      {/* Comment area */}
      <div>
        <textarea
          required
          rows={3}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder={t('yourComment')}
          className="w-full p-3 text-xs bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
        />
      </div>

      {/* Optional Photo Attachment */}
      <div className="flex items-center gap-3">
        <label className="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 bg-white border border-stone-300 rounded-xl text-xs font-semibold text-stone-700 hover:bg-stone-100 transition-colors shadow-2xs">
          <Upload className="w-3.5 h-3.5 text-amber-600" />
          <span>{t('addPhoto')}</span>
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoSelect}
            className="hidden"
          />
        </label>

        {photoPreview && (
          <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-amber-300">
            <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => {
                setPhotoFile(null);
                setPhotoPreview('');
              }}
              className="absolute top-0 right-0 bg-red-600 text-white p-0.5"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-2 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
      >
        <Send className="w-3.5 h-3.5" />
        <span>{loading ? t('submitting') : t('submitReview')}</span>
      </button>
    </form>
  );
};
