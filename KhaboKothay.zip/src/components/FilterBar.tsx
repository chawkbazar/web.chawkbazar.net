import React from 'react';
import { Search, MapPin, DollarSign, Tag, X, SlidersHorizontal, ArrowUpDown } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { FilterState, CuisineType, AreaLocation, PriceRange } from '../types';

interface FilterBarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  totalResults: number;
}

const CUISINES: CuisineType[] = [
  'Bangladeshi',
  'Kacchi & Biryani',
  'Kebab & Grill',
  'Chinese',
  'Fast Food',
  'Thai',
  'Indian',
  'Continental',
  'Cafe & Snacks',
  'Dessert'
];

const AREAS: AreaLocation[] = [
  'Dhanmondi',
  'Gulshan',
  'Banani',
  'Uttara',
  'Mirpur',
  'Baily Road',
  'Mohammadpur',
  'Old Dhaka',
  'Khilgaon',
  'Bashundhara'
];

const PRICES: PriceRange[] = ['৳', '৳৳', '৳৳৳'];

export const FilterBar: React.FC<FilterBarProps> = ({ filters, setFilters, totalResults }) => {
  const { t, language } = useLanguage();

  const toggleCuisine = (cuisine: CuisineType) => {
    setFilters(prev => {
      const exists = prev.selectedCuisines.includes(cuisine);
      return {
        ...prev,
        selectedCuisines: exists 
          ? prev.selectedCuisines.filter(c => c !== cuisine)
          : [...prev.selectedCuisines, cuisine]
      };
    });
  };

  const clearAll = () => {
    setFilters({
      searchQuery: '',
      selectedCuisines: [],
      selectedArea: 'all',
      selectedPriceRange: 'all',
      hasActiveDealOnly: false,
      sortBy: 'rating'
    });
  };

  const activeFilterCount = 
    (filters.selectedCuisines.length > 0 ? 1 : 0) +
    (filters.selectedArea !== 'all' ? 1 : 0) +
    (filters.selectedPriceRange !== 'all' ? 1 : 0) +
    (filters.hasActiveDealOnly ? 1 : 0) +
    (filters.searchQuery.trim().length > 0 ? 1 : 0);

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-stone-200/80 mb-6 space-y-4">
      
      {/* Top Search Bar & Sort Dropdown */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={(e) => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
            placeholder={t('searchPlaceholder')}
            className="w-full pl-10 pr-9 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all placeholder:text-stone-400"
          />
          {filters.searchQuery && (
            <button
              onClick={() => setFilters(prev => ({ ...prev, searchQuery: '' }))}
              className="absolute right-3 top-3 text-stone-400 hover:text-stone-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Sort selector */}
        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
          <ArrowUpDown className="w-4 h-4 text-stone-500 hidden sm:inline" />
          <select
            value={filters.sortBy}
            onChange={(e) => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
            className="w-full sm:w-auto px-3 py-2.5 bg-stone-50 border border-stone-200 text-stone-700 text-xs font-semibold rounded-xl focus:ring-2 focus:ring-amber-500 outline-none cursor-pointer"
          >
            <option value="rating">{t('sortRating')}</option>
            <option value="reviews">{t('sortReviews')}</option>
            <option value="newest">{t('sortNewest')}</option>
          </select>
        </div>
      </div>

      {/* Primary Dropdowns & Deal Toggle */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
        
        {/* Location / Area Dropdown */}
        <div className="flex items-center gap-1.5 bg-stone-50 border border-stone-200 rounded-xl px-3 py-1.5 focus-within:ring-2 focus-within:ring-amber-500">
          <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <select
            value={filters.selectedArea}
            onChange={(e) => setFilters(prev => ({ ...prev, selectedArea: e.target.value }))}
            className="bg-transparent text-stone-800 font-semibold outline-none cursor-pointer pr-1"
          >
            <option value="all">{t('allAreas')}</option>
            {AREAS.map(area => (
              <option key={area} value={area}>{area}</option>
            ))}
          </select>
        </div>

        {/* Price Range */}
        <div className="flex items-center gap-1 bg-stone-50 border border-stone-200 rounded-xl p-1">
          <button
            onClick={() => setFilters(prev => ({ ...prev, selectedPriceRange: 'all' }))}
            className={`px-2 py-1 rounded-lg font-semibold text-[11px] transition-colors ${
              filters.selectedPriceRange === 'all'
                ? 'bg-amber-600 text-white shadow-2xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            {t('allPrices')}
          </button>
          {PRICES.map(p => (
            <button
              key={p}
              onClick={() => setFilters(prev => ({ 
                ...prev, 
                selectedPriceRange: prev.selectedPriceRange === p ? 'all' : p 
              }))}
              className={`px-2 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                filters.selectedPriceRange === p
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {p}
            </button>
          ))}
        </div>

        {/* Has Active Deal Switch */}
        <button
          onClick={() => setFilters(prev => ({ ...prev, hasActiveDealOnly: !prev.hasActiveDealOnly }))}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-semibold transition-all ${
            filters.hasActiveDealOnly
              ? 'bg-red-50 border-red-300 text-red-800 shadow-2xs'
              : 'bg-stone-50 border-stone-200 text-stone-600 hover:border-stone-300'
          }`}
        >
          <Tag className={`w-3.5 h-3.5 ${filters.hasActiveDealOnly ? 'text-red-600 fill-red-100' : 'text-stone-400'}`} />
          <span>{t('hasActiveDeal')}</span>
        </button>

        {/* Clear Filters Button */}
        {activeFilterCount > 0 && (
          <button
            onClick={clearAll}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-stone-500 hover:text-red-600 text-xs font-semibold hover:bg-red-50 transition-colors ml-auto"
          >
            <X className="w-3.5 h-3.5" />
            <span>{t('clearFilters')} ({activeFilterCount})</span>
          </button>
        )}
      </div>

      {/* Cuisine Multi-Select Scrollable Chips */}
      <div>
        <p className="text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-2">
          {t('filterCuisine')}
        </p>
        <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto no-scrollbar py-0.5">
          {CUISINES.map((cuisine) => {
            const isSelected = filters.selectedCuisines.includes(cuisine);
            return (
              <button
                key={cuisine}
                onClick={() => toggleCuisine(cuisine)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-amber-700 text-white font-semibold shadow-xs'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200/80 border border-stone-200/50'
                }`}
              >
                {cuisine}
              </button>
            );
          })}
        </div>
      </div>

      {/* Results Count Banner */}
      <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500 font-medium">
        <span>
          <strong className="text-stone-900 font-bold">{totalResults}</strong> {t('resultsFound')}
        </span>
      </div>

    </div>
  );
};
