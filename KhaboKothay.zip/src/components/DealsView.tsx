import React, { useState } from 'react';
import { Tag, Sparkles, MapPin, Search } from 'lucide-react';
import { Deal, Restaurant } from '../types';
import { DealCard } from './DealCard';
import { useLanguage } from '../context/LanguageContext';

interface DealsViewProps {
  deals: Deal[];
  restaurants: Restaurant[];
  onSelectRestaurant: (restaurant: Restaurant) => void;
}

export const DealsView: React.FC<DealsViewProps> = ({
  deals,
  restaurants,
  onSelectRestaurant
}) => {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArea, setSelectedArea] = useState('all');

  const filteredDeals = deals.filter(deal => {
    const res = restaurants.find(r => r.id === deal.restaurantId);
    const resName = res?.name || deal.restaurantName || '';
    const resArea = res?.area || deal.restaurantArea || '';

    const matchesSearch = 
      deal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesArea = selectedArea === 'all' || resArea === selectedArea;

    return matchesSearch && matchesArea;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-red-900 via-amber-900 to-stone-900 text-white p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1 text-red-300 font-bold text-xs uppercase tracking-wider">
            <Tag className="w-4 h-4 fill-red-300" />
            <span>Bangladeshi Dining Discounts</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            {t('dealsTitle')}
          </h1>
          <p className="text-xs text-stone-300 mt-1">
            {t('dealsSubtitle')}
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl text-center border border-white/20">
          <span className="text-2xl font-black text-amber-300 block">{filteredDeals.length}</span>
          <span className="text-[10px] text-stone-200 uppercase font-bold tracking-wider">Active Deals</span>
        </div>
      </div>

      {/* Filter inputs */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search deals by title, keyword, or restaurant..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 bg-stone-50 border border-stone-200 rounded-xl px-3 py-1.5 text-xs font-semibold">
          <MapPin className="w-3.5 h-3.5 text-amber-600" />
          <select
            value={selectedArea}
            onChange={(e) => setSelectedArea(e.target.value)}
            className="bg-transparent outline-none cursor-pointer"
          >
            <option value="all">{t('allAreas')}</option>
            {['Dhanmondi', 'Gulshan', 'Banani', 'Uttara', 'Mirpur', 'Baily Road', 'Old Dhaka', 'Khilgaon'].map(a => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Deals Listing */}
      {filteredDeals.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 border border-stone-200 text-center space-y-2">
          <Tag className="w-10 h-10 text-stone-300 mx-auto" />
          <p className="text-stone-600 text-xs font-medium">{t('noDealsFound')}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredDeals.map(deal => {
            const res = restaurants.find(r => r.id === deal.restaurantId);
            return (
              <DealCard
                key={deal.id}
                deal={deal}
                restaurant={res}
                onSelectRestaurant={onSelectRestaurant}
              />
            );
          })}
        </div>
      )}

    </div>
  );
};
