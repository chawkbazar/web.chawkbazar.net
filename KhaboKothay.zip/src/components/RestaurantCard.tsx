import React from 'react';
import { Star, MapPin, Tag, Bookmark, Phone, ChevronRight } from 'lucide-react';
import { Restaurant } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

interface RestaurantCardProps {
  restaurant: Restaurant;
  onSelect: (restaurant: Restaurant) => void;
  onRequireAuth?: () => void;
}

export const RestaurantCard: React.FC<RestaurantCardProps> = ({ 
  restaurant, 
  onSelect,
  onRequireAuth 
}) => {
  const { t, language } = useLanguage();
  const { isFavorite, toggleFavorite, userProfile } = useAuth();

  const isFav = isFavorite(restaurant.id);

  const handleBookmarkClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!userProfile) {
      if (onRequireAuth) onRequireAuth();
      return;
    }
    try {
      await toggleFavorite(restaurant.id);
    } catch (err) {
      if (onRequireAuth) onRequireAuth();
    }
  };

  return (
    <div 
      onClick={() => onSelect(restaurant)}
      className="bg-white rounded-2xl border border-stone-200/80 overflow-hidden shadow-2xs hover:shadow-lg transition-all duration-200 cursor-pointer flex flex-col group"
    >
      {/* Cover Image & Badges */}
      <div className="relative h-44 sm:h-48 w-full bg-stone-100 overflow-hidden">
        <img
          src={restaurant.coverPhotoUrl || "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"}
          alt={restaurant.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80";
          }}
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />

        {/* Deal Badge */}
        {restaurant.hasActiveDeal && (
          <div className="absolute top-3 left-3 bg-red-600 text-white font-bold text-[11px] px-2.5 py-1 rounded-full shadow-md flex items-center gap-1 animate-pulse">
            <Tag className="w-3 h-3" />
            <span>{t('activeDealsBadge')}</span>
          </div>
        )}

        {/* Bookmark Favorite Button */}
        <button
          onClick={handleBookmarkClick}
          title={isFav ? t('bookmarked') : t('bookmark')}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all shadow-md ${
            isFav 
              ? 'bg-amber-600 text-white' 
              : 'bg-white/80 hover:bg-white text-stone-700'
          }`}
        >
          <Bookmark className={`w-4 h-4 ${isFav ? 'fill-white' : ''}`} />
        </button>

        {/* Price & Rating Tag overlay bottom */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
          <div className="flex items-center gap-1 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg">
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="font-bold">{restaurant.avgRating ? restaurant.avgRating.toFixed(1) : "New"}</span>
            <span className="text-stone-300 text-[10px]">({restaurant.reviewCount || 0})</span>
          </div>

          <span className="bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg font-bold text-amber-300">
            {restaurant.priceRange || '৳৳'}
          </span>
        </div>
      </div>

      {/* Details Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Restaurant Title */}
          <h3 className="font-bold text-stone-900 text-base leading-snug group-hover:text-amber-700 transition-colors line-clamp-1">
            {restaurant.name}
          </h3>

          {/* Area & Address */}
          <div className="flex items-center gap-1 text-stone-500 text-xs mt-1">
            <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="font-medium text-stone-700">{restaurant.area}</span>
            <span className="text-stone-300">•</span>
            <span className="truncate text-stone-500">{restaurant.address}</span>
          </div>

          {/* Cuisine Chips */}
          <div className="flex flex-wrap gap-1 mt-2.5">
            {restaurant.cuisineTags && restaurant.cuisineTags.slice(0, 3).map((tag, idx) => (
              <span key={idx} className="bg-amber-50 text-amber-900 text-[10px] font-semibold px-2 py-0.5 rounded-md border border-amber-200/50">
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* View details footer */}
        <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs font-semibold text-amber-700">
          <span>{t('viewDetails')}</span>
          <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );
};
