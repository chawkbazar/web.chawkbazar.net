import React from 'react';
import { Tag, Calendar, MapPin, ChevronRight, AlertCircle } from 'lucide-react';
import { Deal, Restaurant } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface DealCardProps {
  deal: Deal;
  restaurant?: Restaurant;
  onSelectRestaurant?: (restaurant: Restaurant) => void;
}

export const DealCard: React.FC<DealCardProps> = ({ deal, restaurant, onSelectRestaurant }) => {
  const { t } = useLanguage();

  return (
    <div className="bg-white rounded-2xl border border-stone-200/90 shadow-xs hover:shadow-md transition-all p-4 flex flex-col sm:flex-row gap-4">
      
      {/* Cover Image */}
      <div className="w-full sm:w-40 h-32 rounded-xl bg-stone-100 overflow-hidden relative shrink-0">
        <img
          src={restaurant?.coverPhotoUrl || deal.restaurantCover || "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=600&q=80"}
          alt={deal.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 left-2 bg-red-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
          <Tag className="w-3 h-3" />
          <span>OFFER</span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
            <span className="font-semibold text-amber-800 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-amber-600" />
              {restaurant?.name || deal.restaurantName || "KhaboKothay Partner"} ({restaurant?.area || deal.restaurantArea || "Dhaka"})
            </span>
          </div>

          <h3 className="text-base font-bold text-stone-900 leading-snug">
            {deal.title}
          </h3>

          <p className="text-xs text-stone-600 mt-1.5 leading-relaxed font-medium">
            {deal.description}
          </p>

          {deal.terms && (
            <p className="text-[11px] text-stone-500 mt-2 flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-stone-400 shrink-0" />
              <span>{t('termsAndConditions')} {deal.terms}</span>
            </p>
          )}
        </div>

        {/* Footer info */}
        <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-stone-500">
            <Calendar className="w-3.5 h-3.5 text-amber-600" />
            <span>{t('validUntil')} {deal.validUntil}</span>
          </div>

          {restaurant && onSelectRestaurant && (
            <button
              onClick={() => onSelectRestaurant(restaurant)}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs flex items-center gap-1 transition-colors shadow-2xs"
            >
              <span>{t('getDealAt')}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
