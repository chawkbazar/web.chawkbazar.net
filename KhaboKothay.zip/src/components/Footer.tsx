import React from 'react';
import { Mail, Phone, MapPin, Heart, Utensils } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const Footer: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <footer className="bg-stone-900 text-stone-300 mt-16 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Column 1: Brand & About */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-amber-600 flex items-center justify-center text-white font-bold">
                <Utensils className="w-4 h-4" />
              </div>
              <span className="font-bold text-xl text-white tracking-tight">
                {language === 'bn' ? 'খাবো কোথায়' : 'KhaboKothay'}
              </span>
            </div>
            <p className="text-sm text-stone-400 leading-relaxed mb-4">
              {t('aboutText')}
            </p>
            <div className="flex items-center gap-2 text-xs text-amber-500 font-medium">
              <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
              <span>Dhaka, Chittagong, Sylhet, Rajshahi & Bangladesh</span>
            </div>
          </div>

          {/* Column 2: Direct Contact Details */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-3 uppercase tracking-wider">
              {t('contactTitle')}
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li className="flex items-center gap-2.5 hover:text-white transition-colors">
                <Mail className="w-4 h-4 text-amber-500 shrink-0" />
                <span>{t('supportEmailLabel')}</span>
                <a href="mailto:khabokothay@gmail.com" className="text-amber-400 font-medium hover:underline">
                  khabokothay@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-2.5 hover:text-white transition-colors">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <span>{t('hotlineLabel')}</span>
                <a href="tel:01948879984" className="text-amber-400 font-semibold hover:underline">
                  01948879984
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Quick Info */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-3 uppercase tracking-wider">
              {language === 'bn' ? 'জনপ্রিয় এলাকা' : 'Popular Dining Hubs'}
            </h3>
            <div className="flex flex-wrap gap-1.5 text-xs text-stone-300">
              {['Dhanmondi', 'Gulshan', 'Banani', 'Uttara', 'Mirpur', 'Baily Road', 'Old Dhaka', 'Khilgaon'].map((area) => (
                <span key={area} className="px-2.5 py-1 rounded-md bg-stone-800 border border-stone-700/60">
                  {area}
                </span>
              ))}
            </div>
          </div>

        </div>

        <div className="border-t border-stone-800 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-4">
          <p>{t('copyright')}</p>
          <p className="flex items-center gap-1">
            Made with <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" /> for Bangladeshi Foodies
          </p>
        </div>
      </div>
    </footer>
  );
};
