import React, { useState, useEffect } from 'react';
import { 
  Store, Plus, Edit, Tag, Trash2, MessageSquare, Star, 
  MapPin, Phone, Calendar, Save, X, CornerDownRight, Check
} from 'lucide-react';
import { 
  collection, query, where, getDocs, addDoc, updateDoc, doc, deleteDoc 
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { Restaurant, Deal, Review, CuisineType, AreaLocation, PriceRange } from '../types';

const CUISINES: CuisineType[] = [
  'Bangladeshi', 'Kacchi & Biryani', 'Kebab & Grill', 'Chinese', 
  'Fast Food', 'Thai', 'Indian', 'Continental', 'Cafe & Snacks', 'Dessert'
];

const AREAS: AreaLocation[] = [
  'Dhanmondi', 'Gulshan', 'Banani', 'Uttara', 'Mirpur', 
  'Baily Road', 'Mohammadpur', 'Old Dhaka', 'Khilgaon', 'Bashundhara'
];

export const OwnerDashboard: React.FC = () => {
  const { t } = useLanguage();
  const { userProfile } = useAuth();

  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [selectedResId, setSelectedResId] = useState<string | null>(null);
  const [dealsMap, setDealsMap] = useState<Record<string, Deal[]>>({});
  const [reviewsMap, setReviewsMap] = useState<Record<string, Review[]>>({});
  const [loading, setLoading] = useState<boolean>(true);

  // Modal forms states
  const [showResModal, setShowResModal] = useState<boolean>(false);
  const [editingRes, setEditingRes] = useState<Restaurant | null>(null);

  // Restaurant Form Data
  const [resName, setResName] = useState('');
  const [resDesc, setResDesc] = useState('');
  const [resArea, setResArea] = useState<AreaLocation>('Dhanmondi');
  const [resAddress, setResAddress] = useState('');
  const [resPrice, setResPrice] = useState<PriceRange>('৳৳');
  const [resPhone, setResPhone] = useState('');
  const [resCoverUrl, setResCoverUrl] = useState('');
  const [resGalleryUrls, setResGalleryUrls] = useState('');
  const [resCuisines, setResCuisines] = useState<CuisineType[]>(['Bangladeshi']);
  const [submittingRes, setSubmittingRes] = useState(false);

  // Deal Form Data
  const [showDealModal, setShowDealModal] = useState(false);
  const [dealResId, setDealResId] = useState<string>('');
  const [dealTitle, setDealTitle] = useState('');
  const [dealDesc, setDealDesc] = useState('');
  const [dealValidFrom, setDealValidFrom] = useState(new Date().toISOString().split('T')[0]);
  const [dealValidUntil, setDealValidUntil] = useState('');
  const [dealTerms, setDealTerms] = useState('');
  const [submittingDeal, setSubmittingDeal] = useState(false);

  // Review Reply State
  const [replyTextMap, setReplyTextMap] = useState<Record<string, string>>({});

  useEffect(() => {
    if (userProfile?.uid) {
      fetchOwnerData();
    }
  }, [userProfile]);

  const fetchOwnerData = async () => {
    if (!userProfile?.uid) return;
    setLoading(true);
    try {
      // Fetch restaurants owned by this user
      const q = query(collection(db, 'restaurants'), where('ownerId', '==', userProfile.uid));
      const resSnap = await getDocs(q);
      const resList: Restaurant[] = [];
      resSnap.forEach(d => {
        resList.push({ id: d.id, ...d.data() } as Restaurant);
      });
      setRestaurants(resList);

      if (resList.length > 0 && !selectedResId) {
        setSelectedResId(resList[0].id);
      }

      // Fetch deals & reviews for each restaurant
      const dMap: Record<string, Deal[]> = {};
      const rMap: Record<string, Review[]> = {};

      for (const resItem of resList) {
        // Deals
        const dealsSnap = await getDocs(collection(db, `restaurants/${resItem.id}/deals`));
        const dList: Deal[] = [];
        dealsSnap.forEach(d => dList.push({ id: d.id, ...d.data() } as Deal));
        dMap[resItem.id] = dList;

        // Reviews
        const reviewsSnap = await getDocs(collection(db, `restaurants/${resItem.id}/reviews`));
        const rList: Review[] = [];
        reviewsSnap.forEach(r => rList.push({ id: r.id, ...r.data() } as Review));
        rMap[resItem.id] = rList;
      }

      setDealsMap(dMap);
      setReviewsMap(rMap);
    } catch (err) {
      console.error("Error loading owner data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAddRes = () => {
    setEditingRes(null);
    setResName('');
    setResDesc('');
    setResArea('Dhanmondi');
    setResAddress('');
    setResPrice('৳৳');
    setResPhone(userProfile?.phone || '');
    setResCoverUrl('https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80');
    setResGalleryUrls('');
    setResCuisines(['Bangladeshi']);
    setShowResModal(true);
  };

  const handleOpenEditRes = (resItem: Restaurant) => {
    setEditingRes(resItem);
    setResName(resItem.name);
    setResDesc(resItem.description || '');
    setResArea((resItem.area as AreaLocation) || 'Dhanmondi');
    setResAddress(resItem.address);
    setResPrice(resItem.priceRange || '৳৳');
    setResPhone(resItem.phone || '');
    setResCoverUrl(resItem.coverPhotoUrl || '');
    setResGalleryUrls(resItem.galleryPhotoUrls ? resItem.galleryPhotoUrls.join(', ') : '');
    setResCuisines(resItem.cuisineTags || ['Bangladeshi']);
    setShowResModal(true);
  };

  const handleSaveRestaurant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile?.uid) return;
    setSubmittingRes(true);

    try {
      const galleryArr = resGalleryUrls.split(',').map(s => s.trim()).filter(Boolean);

      const payload = {
        ownerId: userProfile.uid,
        name: resName.trim(),
        description: resDesc.trim(),
        cuisineTags: resCuisines,
        area: resArea,
        address: resAddress.trim(),
        priceRange: resPrice,
        phone: resPhone.trim(),
        coverPhotoUrl: resCoverUrl.trim() || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
        galleryPhotoUrls: galleryArr,
        avgRating: editingRes ? editingRes.avgRating : 0,
        reviewCount: editingRes ? editingRes.reviewCount : 0,
        createdAt: editingRes ? editingRes.createdAt : new Date().toISOString()
      };

      if (editingRes) {
        await updateDoc(doc(db, 'restaurants', editingRes.id), payload);
      } else {
        await addDoc(collection(db, 'restaurants'), payload);
      }

      setShowResModal(false);
      await fetchOwnerData();
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, 'restaurants');
      alert(err.message || t('errorOccurred'));
    } finally {
      setSubmittingRes(false);
    }
  };

  const handleOpenAddDeal = (resId: string) => {
    setDealResId(resId);
    setDealTitle('');
    setDealDesc('');
    setDealValidFrom(new Date().toISOString().split('T')[0]);
    
    // Default valid for 30 days
    const nextMonth = new Date();
    nextMonth.setDate(nextMonth.getDate() + 30);
    setDealValidUntil(nextMonth.toISOString().split('T')[0]);
    setDealTerms('');
    setShowDealModal(true);
  };

  const handleSaveDeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dealResId) return;
    setSubmittingDeal(true);

    try {
      const dealsCol = collection(db, `restaurants/${dealResId}/deals`);
      await addDoc(dealsCol, {
        title: dealTitle.trim(),
        description: dealDesc.trim(),
        validFrom: dealValidFrom,
        validUntil: dealValidUntil,
        terms: dealTerms.trim(),
        createdAt: new Date().toISOString()
      });

      setShowDealModal(false);
      await fetchOwnerData();
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, `restaurants/${dealResId}/deals`);
      alert(err.message || t('errorOccurred'));
    } finally {
      setSubmittingDeal(false);
    }
  };

  const handleDeleteDeal = async (resId: string, dealId: string) => {
    if (!confirm("Are you sure you want to delete this deal?")) return;
    try {
      await deleteDoc(doc(db, `restaurants/${resId}/deals`, dealId));
      await fetchOwnerData();
    } catch (err) {
      console.error("Delete deal error:", err);
    }
  };

  const handleSendReply = async (resId: string, reviewId: string) => {
    const text = replyTextMap[reviewId];
    if (!text || !text.trim()) return;

    try {
      await updateDoc(doc(db, `restaurants/${resId}/reviews`, reviewId), {
        ownerReply: text.trim()
      });
      setReplyTextMap(prev => ({ ...prev, [reviewId]: '' }));
      await fetchOwnerData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `restaurants/${resId}/reviews/${reviewId}`);
    }
  };

  if (!userProfile || userProfile.role !== 'owner') {
    return (
      <div className="max-w-xl mx-auto my-12 p-8 bg-white rounded-3xl shadow-sm text-center border border-stone-200">
        <Store className="w-12 h-12 text-red-600 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-stone-900 mb-2">{t('navOwnerDashboard')}</h2>
        <p className="text-xs text-stone-600 mb-4">{t('mustBeLoggedInOwner')}</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-stone-900 via-amber-950 to-red-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-stone-950 uppercase tracking-wider">
              {t('roleOwner')}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            {userProfile.name}'s Dashboard
          </h1>
          <p className="text-xs text-stone-300 mt-1">
            Manage your restaurant profiles, create discount deals, and engage with diners across Bangladesh.
          </p>
        </div>

        <button
          onClick={handleOpenAddRes}
          className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-2xl shadow-md flex items-center gap-2 transition-transform active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{t('addNewRestaurant')}</span>
        </button>
      </div>

      {/* Owner Restaurants Grid */}
      <div>
        <h2 className="text-lg font-bold text-stone-900 mb-4 flex items-center gap-2">
          <Store className="w-5 h-5 text-amber-700" />
          <span>{t('myRestaurants')} ({restaurants.length})</span>
        </h2>

        {restaurants.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3">
            <p className="text-stone-500 text-xs">{t('noRestaurantsOwner')}</p>
            <button
              onClick={handleOpenAddRes}
              className="px-4 py-2 bg-amber-700 text-white font-bold text-xs rounded-xl hover:bg-amber-800 transition-colors"
            >
              {t('addNewRestaurant')}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {restaurants.map(res => {
              const resDeals = dealsMap[res.id] || [];
              const resReviews = reviewsMap[res.id] || [];

              return (
                <div key={res.id} className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                  <div>
                    {/* Cover Header */}
                    <div className="h-36 bg-stone-100 relative overflow-hidden">
                      <img src={res.coverPhotoUrl} alt={res.name} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      
                      <div className="absolute top-2 right-2 flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditRes(res)}
                          className="p-2 rounded-xl bg-white/90 hover:bg-white text-stone-800 shadow-md font-semibold text-xs flex items-center gap-1"
                        >
                          <Edit className="w-3.5 h-3.5 text-amber-700" />
                          <span>Edit</span>
                        </button>
                      </div>

                      <div className="absolute bottom-2 left-3 right-3 text-white text-xs flex items-center justify-between">
                        <span className="bg-black/60 px-2 py-0.5 rounded-md font-semibold">{res.area}</span>
                        <span className="bg-amber-500 px-2 py-0.5 rounded-md font-bold text-stone-900">★ {res.avgRating || 5.0}</span>
                      </div>
                    </div>

                    {/* Body */}
                    <div className="p-4 space-y-3">
                      <h3 className="font-bold text-stone-900 text-base">{res.name}</h3>
                      <p className="text-xs text-stone-500 line-clamp-2">{res.address}</p>

                      {/* Stats */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-100 text-xs">
                        <div className="bg-amber-50/60 p-2 rounded-xl border border-amber-200/50 text-center">
                          <span className="font-bold text-amber-900 block text-sm">{resDeals.length}</span>
                          <span className="text-[10px] text-stone-500">Active Deals</span>
                        </div>
                        <div className="bg-stone-50 p-2 rounded-xl border border-stone-200/60 text-center">
                          <span className="font-bold text-stone-900 block text-sm">{resReviews.length}</span>
                          <span className="text-[10px] text-stone-500">Reviews</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="p-4 bg-stone-50 border-t border-stone-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleOpenAddDeal(res.id)}
                      className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white font-semibold text-xs rounded-xl shadow-2xs flex items-center gap-1 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{t('createDeal')}</span>
                    </button>

                    <button
                      onClick={() => setSelectedResId(res.id)}
                      className={`px-3 py-1.5 rounded-xl font-semibold text-xs border transition-colors ${
                        selectedResId === res.id 
                          ? 'bg-amber-700 text-white border-amber-700' 
                          : 'bg-white text-stone-700 border-stone-200 hover:border-amber-400'
                      }`}
                    >
                      View Inbox
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Detail Section: Selected Restaurant's Deals & Reviews Inbox */}
      {selectedResId && (
        <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-stone-100 pb-4">
            <div>
              <h3 className="font-bold text-lg text-stone-900">
                {restaurants.find(r => r.id === selectedResId)?.name} — Management
              </h3>
              <p className="text-xs text-stone-500">
                Manage promotional deals and reply to incoming customer reviews
              </p>
            </div>

            <button
              onClick={() => handleOpenAddDeal(selectedResId)}
              className="px-3.5 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold text-xs rounded-xl flex items-center gap-1 shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('createDeal')}</span>
            </button>
          </div>

          {/* Deals Sub-section */}
          <div>
            <h4 className="font-bold text-sm text-stone-900 mb-3 flex items-center gap-2">
              <Tag className="w-4 h-4 text-red-600" />
              <span>{t('manageDeals')}</span>
            </h4>

            {(!dealsMap[selectedResId] || dealsMap[selectedResId].length === 0) ? (
              <p className="text-xs text-stone-400 italic bg-stone-50 p-4 rounded-2xl">
                No deals created yet for this restaurant.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {dealsMap[selectedResId].map(deal => (
                  <div key={deal.id} className="bg-stone-50 border border-stone-200 rounded-2xl p-3.5 flex items-start justify-between gap-2">
                    <div>
                      <h5 className="font-bold text-xs text-stone-900">{deal.title}</h5>
                      <p className="text-xs text-stone-600 mt-1">{deal.description}</p>
                      <span className="inline-block mt-2 text-[10px] font-semibold text-amber-900 bg-amber-100 px-2 py-0.5 rounded-md">
                        {t('validUntil')} {deal.validUntil}
                      </span>
                    </div>

                    <button
                      onClick={() => handleDeleteDeal(selectedResId, deal.id)}
                      className="text-stone-400 hover:text-red-600 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Reviews Inbox Sub-section */}
          <div className="pt-4 border-t border-stone-100">
            <h4 className="font-bold text-sm text-stone-900 mb-3 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-700" />
              <span>{t('reviewsInbox')}</span>
            </h4>

            {(!reviewsMap[selectedResId] || reviewsMap[selectedResId].length === 0) ? (
              <p className="text-xs text-stone-400 italic bg-stone-50 p-4 rounded-2xl">
                No customer reviews received yet.
              </p>
            ) : (
              <div className="space-y-3">
                {reviewsMap[selectedResId].map(review => (
                  <div key={review.id} className="bg-stone-50 border border-stone-200 rounded-2xl p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-amber-200 text-amber-950 font-bold text-xs flex items-center justify-center">
                          {review.userName ? review.userName.charAt(0) : 'U'}
                        </div>
                        <span className="font-bold text-xs text-stone-900">{review.userName}</span>
                      </div>
                      <div className="flex items-center gap-1 text-amber-600 text-xs font-bold">
                        <Star className="w-3.5 h-3.5 fill-amber-500" />
                        <span>{review.rating} / 5</span>
                      </div>
                    </div>

                    <p className="text-xs text-stone-700 leading-relaxed font-medium">
                      "{review.comment}"
                    </p>

                    {/* Reply box */}
                    {review.ownerReply ? (
                      <div className="bg-amber-100/60 p-2.5 rounded-xl text-xs border-l-2 border-amber-700">
                        <span className="font-bold text-amber-950 block text-[11px]">{t('ownerReplyTitle')}</span>
                        <p className="text-stone-800 mt-0.5 italic">{review.ownerReply}</p>
                      </div>
                    ) : (
                      <div className="pt-2 border-t border-stone-200 space-y-2">
                        <textarea
                          rows={2}
                          value={replyTextMap[review.id] || ''}
                          onChange={(e) => setReplyTextMap({ ...replyTextMap, [review.id]: e.target.value })}
                          placeholder={t('replyPlaceholder')}
                          className="w-full p-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                        />
                        <button
                          onClick={() => handleSendReply(selectedResId, review.id)}
                          className="px-3 py-1.5 bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs rounded-xl shadow-2xs flex items-center gap-1"
                        >
                          <CornerDownRight className="w-3.5 h-3.5" />
                          <span>{t('sendReply')}</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* Add / Edit Restaurant Modal */}
      {showResModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base text-stone-900">
                {editingRes ? t('editRestaurant') : t('addNewRestaurant')}
              </h3>
              <button onClick={() => setShowResModal(false)} className="text-stone-400 hover:text-stone-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveRestaurant} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('restaurantName')}</label>
                <input
                  type="text"
                  required
                  value={resName}
                  onChange={(e) => setResName(e.target.value)}
                  placeholder="e.g. Kacchi Bhai - Dhanmondi"
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('description')}</label>
                <textarea
                  rows={2}
                  value={resDesc}
                  onChange={(e) => setResDesc(e.target.value)}
                  placeholder="Describe your cuisine, specialties, or ambiance..."
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">{t('filterArea')}</label>
                  <select
                    value={resArea}
                    onChange={(e) => setResArea(e.target.value as AreaLocation)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{t('filterPrice')}</label>
                  <select
                    value={resPrice}
                    onChange={(e) => setResPrice(e.target.value as PriceRange)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="৳">৳ (Budget)</option>
                    <option value="৳৳">৳৳ (Moderate)</option>
                    <option value="৳৳৳">৳৳৳ (Fine Dining)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('locationAddress')}</label>
                <input
                  type="text"
                  required
                  value={resAddress}
                  onChange={(e) => setResAddress(e.target.value)}
                  placeholder="Full street address..."
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('phonePlaceholder')}</label>
                <input
                  type="tel"
                  value={resPhone}
                  onChange={(e) => setResPhone(e.target.value)}
                  placeholder="01948879984"
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('coverPhotoUrl')}</label>
                <input
                  type="url"
                  value={resCoverUrl}
                  onChange={(e) => setResCoverUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('filterCuisine')}</label>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto border p-2 rounded-xl">
                  {CUISINES.map(c => {
                    const sel = resCuisines.includes(c);
                    return (
                      <button
                        key={c}
                        type="button"
                        onClick={() => {
                          setResCuisines(prev => sel ? prev.filter(x => x !== c) : [...prev, c]);
                        }}
                        className={`px-2 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                          sel ? 'bg-amber-700 text-white' : 'bg-stone-100 text-stone-700'
                        }`}
                      >
                        {c}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                disabled={submittingRes}
                className="w-full py-2.5 bg-amber-700 text-white font-bold rounded-xl shadow-xs hover:bg-amber-800 transition-colors mt-2"
              >
                {submittingRes ? t('submitting') : t('saveRestaurant')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add Deal Modal */}
      {showDealModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base text-stone-900">{t('createDeal')}</h3>
              <button onClick={() => setShowDealModal(false)} className="text-stone-400 hover:text-stone-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDeal} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('dealTitlePlaceholder')}</label>
                <input
                  type="text"
                  required
                  value={dealTitle}
                  onChange={(e) => setDealTitle(e.target.value)}
                  placeholder="e.g. 20% Flat Discount"
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('dealDescPlaceholder')}</label>
                <textarea
                  rows={2}
                  required
                  value={dealDesc}
                  onChange={(e) => setDealDesc(e.target.value)}
                  placeholder="e.g. Get 20% off total bill on Basmati Kacchi Feast for 2..."
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">{t('validFromDate')}</label>
                  <input
                    type="date"
                    required
                    value={dealValidFrom}
                    onChange={(e) => setDealValidFrom(e.target.value)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">{t('validUntilDate')}</label>
                  <input
                    type="date"
                    required
                    value={dealValidUntil}
                    onChange={(e) => setDealValidUntil(e.target.value)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">{t('termsPlaceholder')}</label>
                <input
                  type="text"
                  value={dealTerms}
                  onChange={(e) => setDealTerms(e.target.value)}
                  placeholder="e.g. Valid for dine-in only"
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={submittingDeal}
                className="w-full py-2.5 bg-red-700 text-white font-bold rounded-xl shadow-xs hover:bg-red-800 transition-colors mt-2"
              >
                {submittingDeal ? t('submitting') : t('saveDeal')}
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
