import React from 'react';
import { Bookmark, Sparkles } from 'lucide-react';
import { Restaurant } from '../types';
import { RestaurantCard } from './RestaurantCard';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

interface FavoritesViewProps {
  restaurants: Restaurant[];
  onSelectRestaurant: (restaurant: Restaurant) => void;
  onRequireAuth: () => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  restaurants,
  onSelectRestaurant,
  onRequireAuth
}) => {
  const { t } = useLanguage();
  const { userProfile, isFavorite } = useAuth();

  const favRestaurants = restaurants.filter(r => isFavorite(r.id));

  if (!userProfile) {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-white rounded-3xl border border-stone-200 text-center shadow-xs space-y-3">
        <Bookmark className="w-12 h-12 text-amber-600 mx-auto" />
        <h2 className="text-xl font-bold text-stone-900">{t('favoritesTitle')}</h2>
        <p className="text-xs text-stone-600 leading-relaxed">
          {t('mustBeLoggedInDiner')}
        </p>
        <button
          onClick={onRequireAuth}
          className="mt-2 px-5 py-2 bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs hover:bg-amber-800 transition-colors"
        >
          {t('signIn')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-900 to-red-950 text-white p-6 sm:p-8 rounded-3xl shadow-lg flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1 text-amber-300 font-bold text-xs uppercase tracking-wider">
            <Bookmark className="w-4 h-4 fill-amber-300" />
            <span>Saved Bookmarks</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            {t('favoritesTitle')}
          </h1>
          <p className="text-xs text-stone-300 mt-1">
            {favRestaurants.length} saved restaurant{favRestaurants.length === 1 ? '' : 's'}
          </p>
        </div>
      </div>

      {/* Grid */}
      {favRestaurants.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 border border-stone-200 text-center space-y-3">
          <Sparkles className="w-10 h-10 text-amber-500 mx-auto" />
          <p className="text-stone-600 font-medium text-xs max-w-sm mx-auto leading-relaxed">
            {t('noFavoritesYet')}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {favRestaurants.map(restaurant => (
            <RestaurantCard
              key={restaurant.id}
              restaurant={restaurant}
              onSelect={onSelectRestaurant}
              onRequireAuth={onRequireAuth}
            />
          ))}
        </div>
      )}

    </div>
  );
};
