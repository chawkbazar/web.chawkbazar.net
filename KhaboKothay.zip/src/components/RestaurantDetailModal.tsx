import React, { useState, useEffect } from 'react';
import { 
  X, Star, MapPin, Phone, Bookmark, Tag, Calendar, 
  MessageSquare, User, CornerDownRight, CheckCircle2,
  ChevronLeft, ChevronRight, Share2, Send
} from 'lucide-react';
import { collection, getDocs, query, orderBy, doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Restaurant, Review, Deal } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { ReviewForm } from './ReviewForm';

interface RestaurantDetailModalProps {
  restaurant: Restaurant | null;
  onClose: () => void;
  onRequireAuth: () => void;
}

export const RestaurantDetailModal: React.FC<RestaurantDetailModalProps> = ({
  restaurant,
  onClose,
  onRequireAuth
}) => {
  const { t, language } = useLanguage();
  const { userProfile, isFavorite, toggleFavorite } = useAuth();

  const [reviews, setReviews] = useState<Review[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loadingData, setLoadingData] = useState<boolean>(true);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number>(0);
  
  // Owner Reply State
  const [replyingReviewId, setReplyingReviewId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState<string>('');
  const [replySubmitting, setReplySubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (!restaurant) return;
    fetchRestaurantSubcollections(restaurant.id);
  }, [restaurant]);

  const fetchRestaurantSubcollections = async (resId: string) => {
    setLoadingData(true);
    try {
      // Fetch reviews
      const reviewsCol = collection(db, `restaurants/${resId}/reviews`);
      const reviewsQuery = query(reviewsCol, orderBy('createdAt', 'desc'));
      const reviewsSnap = await getDocs(reviewsQuery);
      const reviewsList: Review[] = [];
      reviewsSnap.forEach(d => {
        reviewsList.push({ id: d.id, ...d.data() } as Review);
      });
      setReviews(reviewsList);

      // Fetch deals
      const dealsCol = collection(db, `restaurants/${resId}/deals`);
      const dealsSnap = await getDocs(dealsCol);
      const todayStr = new Date().toISOString().split('T')[0];
      const dealsList: Deal[] = [];
      dealsSnap.forEach(d => {
        const data = d.data() as Deal;
        // Filter out expired deals
        if (!data.validUntil || data.validUntil >= todayStr) {
          dealsList.push({ id: d.id, ...data });
        }
      });
      setDeals(dealsList);
    } catch (err) {
      console.warn("Error fetching reviews/deals:", err);
    } finally {
      setLoadingData(false);
    }
  };

  if (!restaurant) return null;

  const isFav = isFavorite(restaurant.id);
  const isOwner = userProfile?.uid === restaurant.ownerId;

  const galleryImages = [
    restaurant.coverPhotoUrl,
    ...(restaurant.galleryPhotoUrls || [])
  ].filter(Boolean);

  const handleOwnerReplySubmit = async (reviewId: string) => {
    if (!replyText.trim()) return;
    setReplySubmitting(true);
    try {
      const reviewDocRef = doc(db, `restaurants/${restaurant.id}/reviews`, reviewId);
      await updateDoc(reviewDocRef, {
        ownerReply: replyText.trim()
      });
      setReplyingReviewId(null);
      setReplyText('');
      await fetchRestaurantSubcollections(restaurant.id);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `restaurants/${restaurant.id}/reviews/${reviewId}`);
    } finally {
      setReplySubmitting(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: restaurant.name,
        text: `${restaurant.name} - ${restaurant.area} on KhaboKothay`,
        url: window.location.href
      }).catch(() => {});
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-stone-200 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header / Gallery Bar */}
        <div className="relative h-64 sm:h-72 bg-stone-900 shrink-0 overflow-hidden">
          <img
            src={galleryImages[selectedPhotoIndex] || "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80"}
            alt={restaurant.name}
            className="w-full h-full object-cover"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-black/20 to-black/30" />

          {/* Close & Share Actions */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-black/50 hover:bg-black/70 text-white backdrop-blur-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShare}
                className="p-2 rounded-full bg-black/50 hover:bg-black/70 text-white backdrop-blur-md transition-colors"
              >
                <Share2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  if (!userProfile) onRequireAuth();
                  else toggleFavorite(restaurant.id);
                }}
                className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                  isFav ? 'bg-amber-600 text-white' : 'bg-black/50 hover:bg-black/70 text-white'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${isFav ? 'fill-white' : ''}`} />
              </button>
            </div>
          </div>

          {/* Gallery navigation thumbnails */}
          {galleryImages.length > 1 && (
            <div className="absolute bottom-3 left-4 right-4 flex items-center gap-2 overflow-x-auto no-scrollbar">
              {galleryImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedPhotoIndex(idx)}
                  className={`w-12 h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                    selectedPhotoIndex === idx ? 'border-amber-400 scale-105 shadow-md' : 'border-white/50 opacity-70'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Main Info Header */}
          <div>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-stone-900 leading-tight">
                  {restaurant.name}
                </h2>
                <div className="flex items-center gap-2 text-xs text-stone-600 mt-1 font-medium">
                  <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{restaurant.area}</span>
                  <span className="text-stone-300">•</span>
                  <span>{restaurant.address}</span>
                </div>
              </div>

              <div className="flex flex-col items-end">
                <div className="flex items-center gap-1 bg-amber-500 text-white font-bold px-2.5 py-1 rounded-xl text-sm shadow-xs">
                  <Star className="w-4 h-4 fill-white" />
                  <span>{restaurant.avgRating ? restaurant.avgRating.toFixed(1) : "New"}</span>
                </div>
                <span className="text-[10px] text-stone-500 font-semibold mt-1">
                  {restaurant.reviewCount || 0} {t('reviewsCount')}
                </span>
              </div>
            </div>

            {/* Price & Cuisines */}
            <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-3 border-t border-stone-100">
              <div className="flex flex-wrap gap-1.5">
                {restaurant.cuisineTags?.map((tag, idx) => (
                  <span key={idx} className="bg-amber-100/70 text-amber-900 text-xs font-semibold px-2.5 py-0.5 rounded-lg">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-500 font-medium">{t('filterPrice')}:</span>
                <span className="font-bold text-stone-900 text-sm">{restaurant.priceRange}</span>
              </div>
            </div>

            {/* Description */}
            {restaurant.description && (
              <p className="text-xs text-stone-600 mt-3 leading-relaxed bg-stone-50 p-3 rounded-xl border border-stone-200/60">
                {restaurant.description}
              </p>
            )}

            {/* Phone Hotline Action */}
            {restaurant.phone && (
              <a
                href={`tel:${restaurant.phone}`}
                className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>{t('callRestaurant')}: {restaurant.phone}</span>
              </a>
            )}
          </div>

          {/* Active Special Deals Section */}
          <div>
            <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2 mb-3">
              <Tag className="w-4 h-4 text-red-600" />
              <span>{t('activeDealsSection')}</span>
              <span className="bg-red-100 text-red-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
                {deals.length}
              </span>
            </h3>

            {deals.length === 0 ? (
              <p className="text-xs text-stone-400 italic bg-stone-50 p-3 rounded-xl">
                {t('noDealsFound')}
              </p>
            ) : (
              <div className="space-y-3">
                {deals.map(deal => (
                  <div key={deal.id} className="bg-gradient-to-r from-red-50 to-amber-50 border border-red-200/80 rounded-2xl p-3.5 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-stone-900 text-sm">{deal.title}</h4>
                      <span className="text-[10px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded-md">
                        {t('validUntil')} {deal.validUntil}
                      </span>
                    </div>
                    <p className="text-xs text-stone-700 mt-1">{deal.description}</p>
                    {deal.terms && (
                      <p className="text-[10px] text-stone-500 mt-1 italic">
                        {t('termsAndConditions')} {deal.terms}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Reviews List & Form Section */}
          <div className="pt-4 border-t border-stone-200">
            <h3 className="font-bold text-stone-900 text-base mb-3 flex items-center justify-between">
              <span>{t('reviewsHeading')} ({reviews.length})</span>
            </h3>

            {/* Review Form */}
            <ReviewForm
              restaurantId={restaurant.id}
              onReviewSubmitted={() => fetchRestaurantSubcollections(restaurant.id)}
              onRequireAuth={onRequireAuth}
            />

            {/* Reviews Listing */}
            {reviews.length === 0 ? (
              <p className="text-xs text-stone-500 text-center py-6 bg-stone-50 rounded-2xl">
                {t('noReviewsYet')}
              </p>
            ) : (
              <div className="space-y-3 mt-4">
                {reviews.map(review => (
                  <div key={review.id} className="bg-white border border-stone-200 rounded-2xl p-3.5 shadow-2xs space-y-2">
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-amber-100 text-amber-900 font-bold text-xs flex items-center justify-center">
                          {review.userName ? review.userName.charAt(0).toUpperCase() : 'F'}
                        </div>
                        <div>
                          <span className="font-bold text-xs text-stone-900 block leading-none">
                            {review.userName}
                          </span>
                          <span className="text-[10px] text-stone-400">
                            {review.createdAt ? new Date(review.createdAt).toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US') : ''}
                          </span>
                        </div>
                      </div>

                      {/* Rating stars */}
                      <div className="flex items-center gap-0.5 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span className="font-bold text-xs text-amber-900">{review.rating}</span>
                      </div>
                    </div>

                    <p className="text-xs text-stone-700 leading-relaxed font-medium">
                      {review.comment}
                    </p>

                    {review.photoUrl && (
                      <div className="w-20 h-20 rounded-xl overflow-hidden border border-stone-200">
                        <img src={review.photoUrl} alt="Review" className="w-full h-full object-cover" />
                      </div>
                    )}

                    {/* Owner Reply Display */}
                    {review.ownerReply && (
                      <div className="mt-2 p-2.5 bg-amber-50/80 border-l-2 border-amber-600 rounded-r-xl text-xs text-stone-800">
                        <span className="font-bold text-amber-950 block mb-0.5 flex items-center gap-1">
                          <CornerDownRight className="w-3 h-3 text-amber-700" />
                          {t('ownerReplyTitle')}
                        </span>
                        <p className="text-stone-700 italic">{review.ownerReply}</p>
                      </div>
                    )}

                    {/* Owner Reply Action (If logged in owner) */}
                    {isOwner && !review.ownerReply && (
                      <div className="mt-2 pt-2 border-t border-stone-100">
                        {replyingReviewId === review.id ? (
                          <div className="space-y-2">
                            <textarea
                              rows={2}
                              value={replyText}
                              onChange={(e) => setReplyText(e.target.value)}
                              placeholder={t('replyPlaceholder')}
                              className="w-full p-2 text-xs border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                            />
                            <div className="flex justify-end gap-2">
                              <button
                                onClick={() => setReplyingReviewId(null)}
                                className="px-3 py-1 text-xs text-stone-600 hover:text-stone-800"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => handleOwnerReplySubmit(review.id)}
                                disabled={replySubmitting}
                                className="px-3 py-1 bg-amber-700 text-white rounded-lg text-xs font-bold hover:bg-amber-800"
                              >
                                {replySubmitting ? t('submitting') : t('sendReply')}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setReplyingReviewId(review.id);
                              setReplyText('');
                            }}
                            className="text-xs font-bold text-amber-800 hover:underline flex items-center gap-1"
                          >
                            <CornerDownRight className="w-3 h-3" />
                            <span>{t('replyToReview')}</span>
                          </button>
                        )}
                      </div>
                    )}

                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
