export type UserRole = 'diner' | 'owner';

export type Language = 'bn' | 'en';

export type PriceRange = '৳' | '৳৳' | '৳৳৳';

export type AreaLocation = 
  | 'Dhanmondi'
  | 'Gulshan'
  | 'Banani'
  | 'Uttara'
  | 'Mirpur'
  | 'Baily Road'
  | 'Mohammadpur'
  | 'Old Dhaka'
  | 'Khilgaon'
  | 'Bashundhara';

export type CuisineType = 
  | 'Bangladeshi'
  | 'Kacchi & Biryani'
  | 'Kebab & Grill'
  | 'Chinese'
  | 'Fast Food'
  | 'Thai'
  | 'Indian'
  | 'Continental'
  | 'Cafe & Snacks'
  | 'Dessert';

export interface UserProfile {
  uid: string;
  role: UserRole;
  name: string;
  email: string;
  phone?: string;
  languagePreference?: Language;
  favorites?: string[]; // Array of restaurant IDs
  createdAt?: string;
}

export interface Restaurant {
  id: string;
  ownerId: string;
  name: string;
  description: string;
  cuisineTags: CuisineType[];
  area: AreaLocation | string;
  address: string;
  priceRange: PriceRange;
  coverPhotoUrl: string;
  galleryPhotoUrls: string[];
  phone: string;
  avgRating: number;
  reviewCount: number;
  createdAt: string;
  hasActiveDeal?: boolean;
}

export interface Review {
  id: string;
  restaurantId: string;
  userId: string;
  userName: string;
  rating: number; // 1 - 5
  comment: string;
  photoUrl?: string;
  ownerReply?: string;
  createdAt: string;
}

export interface Deal {
  id: string;
  restaurantId: string;
  restaurantName?: string;
  restaurantCover?: string;
  restaurantArea?: string;
  title: string;
  description: string;
  validFrom: string; // YYYY-MM-DD
  validUntil: string; // YYYY-MM-DD
  terms?: string;
  createdAt: string;
}

export interface FilterState {
  searchQuery: string;
  selectedCuisines: CuisineType[];
  selectedArea: string; // 'all' or specific area
  selectedPriceRange: string; // 'all' or specific price range
  hasActiveDealOnly: boolean;
  sortBy: 'rating' | 'reviews' | 'newest';
}
